const express = require('express');
const cors = require('cors');
const db = require('./db');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// 1. Поиск профессий и навыков
app.get('/api/professions', async (req, res) => {
    try {
        const search = req.query.search || '';
        const sql = `
            SELECT p.id, p.title, p.demand_level, p.salary_avg, p.required_education,
                   GROUP_CONCAT(c.name SEPARATOR ', ') AS skills
            FROM professions p
            LEFT JOIN profession_competencies pc ON p.id = pc.profession_id
            LEFT JOIN competencies c ON pc.competency_id = c.id
            WHERE p.title LIKE ? OR c.name LIKE ?
            GROUP BY p.id, p.title, p.demand_level, p.salary_avg, p.required_education
        `;
        const queryParam = `%${search}%`;
        const [rows] = await db.query(sql, [queryParam, queryParam]);
        res.json(rows);
    } catch (error) {
        console.error("Ошибка API профессий:", error);
        res.status(500).json({ error: error.message });
    }
});

// 2. Список ВУЗов
app.get('/api/universities', async (req, res) => {
    try {
        const [unis] = await db.query('SELECT * FROM universities');
        const [dirs] = await db.query('SELECT * FROM directions');

        const result = unis.map(u => ({
            ...u,
            directions: dirs.filter(d => d.university_id === u.id)
        }));

        res.json(result);
    } catch (error) {
        console.error("Ошибка API ВУЗов:", error);
        res.status(500).json({ error: error.message });
    }
});

// 3. Расчет траектории
app.post('/api/trajectory', async (req, res) => {
    try {
        const { subject, score } = req.body;
        const userScore = parseInt(score) || 0;
        let examName = 'Информатика';
        if (subject === 'Physics') examName = 'Физика';

        const [suitableDirections] = await db.query(
            `SELECT u.name AS uni_name, d.title AS dir_title, d.passing_score 
             FROM directions d 
             JOIN universities u ON d.university_id = u.id 
             WHERE d.exams LIKE ? AND d.passing_score <= ?`,
            [`%${examName}%`, userScore]
        );

        const searchKeyword = subject === 'IT' ? '%Информатика%' : '%Мехатроника%';
        const [suitableProfessions] = await db.query(
            `SELECT * FROM professions WHERE required_education LIKE ?`,
            [searchKeyword]
        );

        const steps = [
            `1. Сдать ЕГЭ: Математика (профиль), Русский язык, ${examName} (Ваш балл: ${userScore}).`,
            suitableDirections.length > 0 
                ? `2. Поступить в ВУЗ: Доступно ${suitableDirections.length} направлений (например: ${suitableDirections[0].uni_name} — "${suitableDirections[0].dir_title}").`
                : '2. Подать документы на контракт или подтянуть баллы ЕГЭ.',
            '3. Освоить профильные компетенции и пройти стажировку со 3 курса.',
            suitableProfessions.length > 0 
                ? `4. Трудоустройство: ${suitableProfessions.map(p => p.title).join(' / ')} (средняя ЗП: ${suitableProfessions[0].salary_avg} руб.).`
                : '4. Выход на рынок труда по специальности.'
        ];

        res.json({ steps });
    } catch (error) {
        console.error("Ошибка API траектории:", error);
        res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Сервер бэкенда запущен на порту ${PORT}`);
});