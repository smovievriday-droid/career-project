<template>
  <div>
    <h2 class="text-3xl font-bold mb-4 text-gray-800">Модуль для абитуриентов</h2>
    <p class="text-gray-600 mb-4">Добро пожаловать в «Карьерный навигатор». Выберите интересующий раздел.</p>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
      <div class="p-4 border rounded-lg bg-blue-50">
        <h3 class="font-bold text-xl mb-2 text-blue-700">1. Специалисты</h3>
        <p>Востребованные профессии и экзамены.</p>
      </div>
      <div class="p-4 border rounded-lg bg-green-50">
        <h3 class="font-bold text-xl mb-2 text-green-700">2. ВУЗы</h3>
        <p>Список институтов и условия поступления.</p>
      </div>
      <div class="p-4 border rounded-lg bg-purple-50">
        <h3 class="font-bold text-xl mb-2 text-purple-700">3. Траектория</h3>
        <p>Планирование обучения и карьеры.</p>
      </div>
    </div>
  </div>
</template>