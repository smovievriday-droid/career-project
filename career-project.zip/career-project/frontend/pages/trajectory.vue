<template>
  <div>
    <h2 class="text-2xl font-bold mb-4">Планирование образовательной траектории</h2>
    <div class="bg-gray-50 p-6 rounded border max-w-lg">
      <label class="block mb-2 font-bold">Выберите профильные предметы:</label>
      <select v-model="selectedInterest" class="w-full p-2 border rounded mb-4">
        <option value="">-- Выберите --</option>
        <option value="IT">Информатика и Математика</option>
        <option value="Physics">Физика и Математика</option>
      </select>

      <button @click="generatePlan" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Построить план</button>
    </div>

    <div v-if="resultPlan" class="mt-6 p-4 bg-green-100 border border-green-400 rounded">
      <h3 class="font-bold text-lg text-green-800">Рекомендуемый план развития:</h3>
      <p class="mt-2 text-gray-800">{{ resultPlan }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const selectedInterest = ref('')
const resultPlan = ref('')

const generatePlan = () => {
  if (selectedInterest.value === 'IT') {
    resultPlan.value = '1. Сдать ЕГЭ (Информатика, Математика) -> 2. Поступить в ИТМО или УрФУ -> 3. Стажировка со 3 курса -> 4. Frontend-разработчик.'
  } else if (selectedInterest.value === 'Physics') {
    resultPlan.value = '1. Сдать ЕГЭ (Физика, Математика) -> 2. Поступить в МГТУ Баумана -> 3. Практика в КБ -> 4. Инженер-робототехник.'
  } else {
    resultPlan.value = 'Выберите вариант из списка.'
  }
}
</script>