<template>
  <div>
    <h2 class="text-2xl font-bold mb-4">Поиск востребованных специалистов</h2>
    <input v-model="searchQuery" type="text" placeholder="Поиск по профессиям..." class="w-full p-2 border rounded mb-6" />
    
    <div class="grid gap-4">
      <div v-for="prof in filteredProfessions" :key="prof.id" class="p-4 border rounded shadow-sm bg-gray-50">
        <h3 class="text-xl font-bold text-blue-600">{{ prof.title }}</h3>
        <p><strong>Востребованность:</strong> {{ prof.demand_level }}</p>
        <p><strong>Средняя ЗП:</strong> {{ prof.salary_avg }} руб.</p>
        <p><strong>Образование:</strong> {{ prof.required_education }}</p>
        <p><strong>ЕГЭ:</strong> {{ prof.exams }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
const { data: professions } = await useFetch('http://localhost:5000/api/professions')
const searchQuery = ref('')

const filteredProfessions = computed(() => {
  if (!professions.value) return []
  return professions.value.filter(p => p.title.toLowerCase().includes(searchQuery.value.toLowerCase()))
})
</script>