<template>
  <div>
    <h2 class="text-2xl font-bold mb-4">Список ВУЗов и требования для поступления</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div v-for="uni in universities" :key="uni.id" class="p-4 border rounded-lg border-l-4 border-l-blue-500 bg-gray-50">
        <h3 class="text-xl font-bold">{{ uni.name }}</h3>
        <p class="text-gray-500 mb-2">Город: {{ uni.city }}</p>
        <p><strong>Направления:</strong> {{ uni.directions }}</p>
        <p class="text-red-600 font-bold mt-2">Минимальный проходной балл: {{ uni.passing_score }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
const { data: universities } = await useFetch('http://localhost:5000/api/universities')
</script>