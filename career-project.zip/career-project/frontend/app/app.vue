<template>
  <div class="min-h-screen bg-gray-100 font-sans">
    <header class="bg-blue-600 text-white p-4 shadow-md">
      <div class="container mx-auto flex justify-between items-center">
        <h1 class="text-2xl font-bold cursor-pointer" @click="currentTab = 'main'">Карьерный навигатор</h1>
        <nav class="space-x-2 md:space-x-4">
          <button @click="currentTab = 'main'" :class="['px-3 py-1.5 rounded-lg transition', currentTab === 'main' ? 'bg-blue-800 font-bold' : 'hover:bg-blue-700']">Главная</button>
          <button @click="currentTab = 'professions'; fetchProfessions()" :class="['px-3 py-1.5 rounded-lg transition', currentTab === 'professions' ? 'bg-blue-800 font-bold' : 'hover:bg-blue-700']">Профессии</button>
          <button @click="currentTab = 'universities'; fetchUniversities()" :class="['px-3 py-1.5 rounded-lg transition', currentTab === 'universities' ? 'bg-blue-800 font-bold' : 'hover:bg-blue-700']">ВУЗы</button>
          <button @click="currentTab = 'trajectory'" :class="['px-3 py-1.5 rounded-lg transition', currentTab === 'trajectory' ? 'bg-blue-800 font-bold' : 'hover:bg-blue-700']">Траектория</button>
        </nav>
      </div>
    </header>

    <main class="container mx-auto p-6 mt-6 bg-white rounded-xl shadow-md min-h-[500px]">
      
      <!-- Вкладка 1: Главная -->
      <div v-if="currentTab === 'main'">
        <h2 class="text-3xl font-bold mb-4 text-gray-800">Модуль для абитуриентов</h2>
        <p class="text-gray-600 mb-6 text-lg">Единая система выбора образовательной и карьерной траектории.</p>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div @click="currentTab = 'professions'; fetchProfessions()" class="p-6 border rounded-xl bg-blue-50 hover:shadow-lg transition cursor-pointer">
            <h3 class="font-bold text-xl mb-2 text-blue-700">1. Серверный поиск специалистов</h3>
            <p class="text-gray-600">Поиск по названию специальности или навыкам (SQL API).</p>
          </div>
          <div @click="currentTab = 'universities'; fetchUniversities()" class="p-6 border rounded-xl bg-green-50 hover:shadow-lg transition cursor-pointer">
            <h3 class="font-bold text-xl mb-2 text-green-700">2. Каталог ВУЗов</h3>
            <p class="text-gray-600">Условия поступления, направления и проходные баллы из базы данных.</p>
          </div>
          <div @click="currentTab = 'trajectory'" class="p-6 border rounded-xl bg-purple-50 hover:shadow-lg transition cursor-pointer">
            <h3 class="font-bold text-xl mb-2 text-purple-700">3. Расчет траектории (API)</h3>
            <p class="text-gray-600">Интеллектуальный серверный алгоритм подбора ВУЗа и карьеры.</p>
          </div>
        </div>
      </div>

      <!-- Вкладка 2: Профессии (Серверный поиск) -->
      <div v-if="currentTab === 'professions'">
        <h2 class="text-2xl font-bold mb-2 text-gray-800">Поиск специалистов (Server-side Search API)</h2>
        <p class="text-sm text-gray-500 mb-4">Поиск выполняется на сервере MySQL по названию профессии и навыкам (например, 'Vue', 'Python', 'Инженер').</p>

        <div class="flex gap-2 mb-6">
          <input v-model="searchQuery" @keyup.enter="fetchProfessions" type="text" placeholder="Введите профессию или навык..." class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <button @click="fetchProfessions" class="bg-blue-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-blue-700">Искать</button>
        </div>

        <div v-if="loading" class="text-gray-500 py-4">Загрузка через API...</div>
        <div v-else-if="professions.length === 0" class="text-gray-500 py-4">Ничего не найдено на сервере.</div>

        <div v-else class="grid gap-4">
          <div v-for="prof in professions" :key="prof.id" class="p-5 border rounded-lg bg-gray-50 shadow-sm">
            <h3 class="text-xl font-bold text-blue-600 mb-2">{{ prof.title }}</h3>
            <p class="text-gray-700"><strong>Спрос:</strong> <span class="text-green-600 font-semibold">{{ prof.demand_level }}</span></p>
            <p class="text-gray-700"><strong>Средняя ЗП:</strong> {{ prof.salary_avg ? prof.salary_avg.toLocaleString() : '---' }} руб.</p>
            <p class="text-gray-700"><strong>Образование:</strong> {{ prof.required_education }}</p>
            <p class="text-gray-700 mt-2"><strong>Ключевые навыки (БД):</strong> <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">{{ prof.skills || 'Не указаны' }}</span></p>
          </div>
        </div>
      </div>

      <!-- Вкладка 3: ВУЗы -->
      <div v-if="currentTab === 'universities'">
        <h2 class="text-2xl font-bold mb-4 text-gray-800">Список ВУЗов и условия поступления</h2>
        <div v-if="loading" class="text-gray-500 py-4">Загрузка из БД...</div>
        <div v-else class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div v-for="uni in universities" :key="uni.id" class="p-5 border rounded-lg border-l-4 border-l-blue-500 bg-gray-50 shadow-sm">
            <h3 class="text-xl font-bold text-gray-800">{{ uni.name }}</h3>
            <p class="text-gray-500 mb-3">Город: {{ uni.city }}</p>
            <h4 class="font-bold text-gray-700 mb-2">Направления подготовки:</h4>
            <ul class="space-y-2">
              <li v-for="(dir, idx) in uni.directions" :key="idx" class="bg-white p-2 border rounded text-sm">
                <div class="font-semibold text-blue-700">{{ dir.title }}</div>
                <div class="text-gray-600">Экзамены: {{ dir.exams }}</div>
                <div class="text-red-600 font-bold">Проходной балл: {{ dir.passing_score }}</div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Вкладка 4: Траектория через API -->
      <div v-if="currentTab === 'trajectory'">
        <h2 class="text-2xl font-bold mb-4 text-gray-800">Планирование траектории через API Бэкенда</h2>
        <div class="bg-gray-50 p-6 rounded-lg border max-w-xl shadow-sm">
          <label class="block mb-2 font-bold text-gray-700">1. Профильный предмет:</label>
          <select v-model="selectedSubject" class="w-full p-3 border rounded-lg mb-4 bg-white">
            <option value="IT">Информатика</option>
            <option value="Physics">Физика</option>
          </select>

          <label class="block mb-2 font-bold text-gray-700">2. Сумма баллов ЕГЭ за 3 предмета:</label>
          <input v-model="userScore" type="number" placeholder="Например: 265" class="w-full p-3 border rounded-lg mb-4 bg-white" />

          <button @click="calculateTrajectory" class="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition">
            Рассчитать траекторию на сервере
          </button>
        </div>

        <div v-if="trajectoryResult" class="mt-6 p-6 bg-green-50 border border-green-300 rounded-lg shadow-sm">
          <h3 class="font-bold text-xl text-green-800 mb-4">Результат анализа API:</h3>
          
          <div class="space-y-2 mb-4">
            <div v-for="(step, idx) in trajectoryResult.steps" :key="idx" class="p-3 bg-white border rounded text-gray-800 font-medium">
              {{ step }}
            </div>
          </div>
        </div>
      </div>

    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const currentTab = ref('main')
const searchQuery = ref('')
const loading = ref(false)

const professions = ref([])
const universities = ref([])

const selectedSubject = ref('IT')
const userScore = ref(260)
const trajectoryResult = ref(null)

// Серверный поиск
const fetchProfessions = async () => {
  loading.value = true
  try {
    const res = await fetch(`http://localhost:5000/api/professions?search=${encodeURIComponent(searchQuery.value)}`)
    professions.value = await res.json()
  } catch (err) {
    console.error(err)
  } finally {
    loading.value = false
  }
}

const fetchUniversities = async () => {
  loading.value = true
  try {
    const res = await fetch('http://localhost:5000/api/universities')
    universities.value = await res.json()
  } catch (err) {
    console.error(err)
  } finally {
    loading.value = false
  }
}

// Запрос планирования на сервер
const calculateTrajectory = async () => {
  try {
    const res = await fetch('http://localhost:5000/api/trajectory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject: selectedSubject.value,
        score: userScore.value
      })
    })
    trajectoryResult.value = await res.json()
  } catch (err) {
    console.error(err)
  }
}

onMounted(() => {
  fetchProfessions()
  fetchUniversities()
})
</script>