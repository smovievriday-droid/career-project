export default defineNuxtConfig({
  app: {
    head: {
      title: 'Карьерный навигатор',
      script: [
        { src: 'https://cdn.tailwindcss.com' }
      ]
    }
  }
})